import { motion } from 'framer-motion';
import { ArrowRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const HeroCTA = () => {
  return (
    <motion.div 
      className="relative z-20 text-center lg:text-left max-w-xl"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
    >
      {/* Badge */}
      <motion.div
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary border border-border mb-6"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5 }}
      >
        <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
        <span className="text-xs font-medium text-foreground">Now with real-time sync</span>
      </motion.div>

      {/* Headline */}
      <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-4">
        Turn Facebook Marketplace Leads Into{' '}
        <span className="text-gradient-primary">Signed Leases</span>
        {' '}— Automatically
      </h1>

      {/* Subheadline */}
      <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
        Sync Facebook Marketplace leads, listings, and conversations directly into your leasing workflow.{' '}
        <span className="text-foreground font-medium">Never lose a lead again.</span>
      </p>

      {/* CTA Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-4 mb-6">
        <Button 
          size="lg" 
          className="w-full sm:w-auto group bg-gradient-primary hover:opacity-90 text-primary-foreground shadow-lg shadow-primary/25 transition-all"
        >
          Connect Facebook Marketplace Now
          <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
        </Button>
        <Button 
          variant="outline" 
          size="lg" 
          className="w-full sm:w-auto border-border hover:bg-secondary"
        >
          Watch Demo
        </Button>
      </div>

      {/* Secondary text */}
      <div className="flex flex-wrap items-center justify-center lg:justify-start gap-x-4 gap-y-2 text-sm text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <Check className="w-4 h-4 text-success" />
          Start free
        </span>
        <span className="flex items-center gap-1.5">
          <Check className="w-4 h-4 text-success" />
          No credit card
        </span>
        <span className="flex items-center gap-1.5">
          <Check className="w-4 h-4 text-success" />
          5-minute setup
        </span>
      </div>
    </motion.div>
  );
};
