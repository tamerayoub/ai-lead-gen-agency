import { motion } from 'framer-motion';
import { Inbox, Users, Home, ClipboardCheck, ArrowRight, MessageSquare, Calendar, FileText } from 'lucide-react';

const pipelineStages = [
  { id: 1, name: 'New', count: 12, color: 'bg-accent' },
  { id: 2, name: 'Contacted', count: 8, color: 'bg-primary' },
  { id: 3, name: 'Touring', count: 5, color: 'bg-success' },
  { id: 4, name: 'Applied', count: 3, color: 'bg-facebook' },
];

const recentLeads = [
  { id: 1, name: 'Sarah Mitchell', property: '2BR Downtown', status: 'New Lead', time: 'Just now' },
  { id: 2, name: 'James Kim', property: 'Studio Campus', status: 'Tour Scheduled', time: '5m ago' },
];

export const CRMWorkflowPanel = () => {
  return (
    <motion.div 
      className="relative w-full h-full bg-card rounded-2xl shadow-card overflow-hidden border border-border/50"
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
    >
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-border bg-secondary/30">
        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-primary">
          <Home className="w-5 h-5 text-primary-foreground" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground text-sm">Your Leasing Workflow</h3>
        </div>
        <div className="ml-auto flex items-center gap-1.5 px-2 py-1 rounded-full bg-success-light">
          <span className="w-1.5 h-1.5 rounded-full bg-success" />
          <span className="text-xs text-success font-medium">Synced</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Pipeline */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Leasing Pipeline</p>
          <div className="flex items-center gap-2">
            {pipelineStages.map((stage, index) => (
              <motion.div
                key={stage.id}
                className="flex-1 relative"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 + index * 0.1 }}
              >
                <div className="flex flex-col items-center p-2 rounded-lg bg-secondary/50 border border-border/30">
                  <div className={`w-8 h-8 rounded-full ${stage.color} flex items-center justify-center mb-1`}>
                    <span className="text-xs font-bold text-primary-foreground">{stage.count}</span>
                  </div>
                  <span className="text-xs font-medium text-foreground">{stage.name}</span>
                </div>
                {index < pipelineStages.length - 1 && (
                  <ArrowRight className="absolute -right-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground z-10" />
                )}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Lead Inbox */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Lead Inbox</p>
            <span className="flex items-center gap-1 text-xs text-primary font-medium">
              <Inbox className="w-3 h-3" />
              12 new
            </span>
          </div>
          <div className="space-y-2">
            {recentLeads.map((lead, index) => (
              <motion.div
                key={lead.id}
                className="p-3 rounded-lg bg-card border border-border/30 hover:border-primary/30 transition-colors"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 + index * 0.15 }}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Users className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{lead.name}</p>
                      <p className="text-xs text-muted-foreground">{lead.property}</p>
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground">{lead.time}</span>
                </div>
                <div className="flex items-center gap-3 mt-2 pt-2 border-t border-border/30">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    lead.status === 'New Lead' 
                      ? 'bg-accent/20 text-accent' 
                      : 'bg-success-light text-success'
                  }`}>
                    {lead.status}
                  </span>
                  <div className="flex items-center gap-2 ml-auto">
                    <button className="p-1 rounded hover:bg-secondary transition-colors">
                      <MessageSquare className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                    <button className="p-1 rounded hover:bg-secondary transition-colors">
                      <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                    <button className="p-1 rounded hover:bg-secondary transition-colors">
                      <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Activity indicator */}
        <motion.div 
          className="flex items-center gap-2 p-2 rounded-lg bg-success-light/50 border border-success/20"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
        >
          <ClipboardCheck className="w-4 h-4 text-success" />
          <span className="text-xs text-success font-medium">All conversations synced • History preserved</span>
        </motion.div>
      </div>

      {/* Bottom indicator */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-primary" />
    </motion.div>
  );
};
