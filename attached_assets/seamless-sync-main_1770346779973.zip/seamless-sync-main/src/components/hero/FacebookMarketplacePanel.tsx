import { motion } from 'framer-motion';
import { MessageCircle, Heart, MapPin, User, Home } from 'lucide-react';

// Official Facebook "F" Logo Component
const FacebookLogo = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 40 40" fill="none" className={className}>
    <circle cx="20" cy="20" r="20" fill="#1877F2"/>
    <path 
      d="M27.785 25.781L28.672 20H23.125V16.25C23.125 14.797 23.836 13.375 26.117 13.375H28.875V8.359C28.875 8.359 26.32 7.875 23.879 7.875C18.772 7.875 15.312 11.083 15.312 16.688V20H10.203V25.781H15.312V38.719C16.335 38.875 17.379 39 18.438 39C19.496 39 20.54 38.875 21.562 38.719V25.781H27.785Z" 
      fill="white"
    />
  </svg>
);

const listings = [
  { id: 1, title: '2BR Apartment Downtown', price: '$1,850/mo', location: 'Financial District' },
  { id: 2, title: 'Studio Near Campus', price: '$1,200/mo', location: 'University Area' },
  { id: 3, title: '3BR Family Home', price: '$2,400/mo', location: 'Suburbia Heights' },
];

const messages = [
  { id: 1, name: 'Sarah M.', message: 'Is the 2BR still available?', time: '2m ago' },
  { id: 2, name: 'James K.', message: 'Can I schedule a tour?', time: '5m ago' },
  { id: 3, name: 'Maria L.', message: 'What are the pet policies?', time: '8m ago' },
];

export const FacebookMarketplacePanel = () => {
  return (
    <motion.div 
      className="relative w-full h-full bg-card rounded-2xl shadow-card overflow-hidden border border-border/50"
      initial={{ opacity: 0, x: -30 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
    >
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-border bg-secondary/30">
        <FacebookLogo className="w-10 h-10" />
        <div>
          <h3 className="font-semibold text-foreground text-sm">Facebook Marketplace</h3>
          <p className="text-xs text-muted-foreground">Your Rental Listings</p>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
          <span className="text-xs text-success font-medium">Live</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Listings Section */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Active Listings</p>
          <div className="space-y-2">
            {listings.map((listing, index) => (
              <motion.div
                key={listing.id}
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 border border-border/30 hover:border-primary/30 transition-colors"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <Home className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{listing.title}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <MapPin className="w-3 h-3" />
                    <span>{listing.location}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-primary">{listing.price}</p>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Heart className="w-3 h-3" />
                    <span className="text-xs">24</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Messages Section */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">New Messages</p>
          <div className="space-y-2">
            {messages.map((msg, index) => (
              <motion.div
                key={msg.id}
                className="flex items-start gap-3 p-3 rounded-lg bg-card border border-border/30"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + index * 0.15 }}
              >
                <div className="w-9 h-9 rounded-full bg-facebook-light/20 flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-facebook" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium text-foreground">{msg.name}</p>
                    <span className="text-xs text-muted-foreground flex-shrink-0">{msg.time}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 truncate">{msg.message}</p>
                </div>
                <MessageCircle className="w-4 h-4 text-facebook flex-shrink-0 mt-0.5" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom indicator */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-facebook via-facebook-light to-facebook" />
    </motion.div>
  );
};
