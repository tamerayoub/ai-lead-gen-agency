import { motion } from 'framer-motion';
import { FacebookMarketplacePanel } from './FacebookMarketplacePanel';
import { CRMWorkflowPanel } from './CRMWorkflowPanel';
import { DataFlowBridge } from './DataFlowBridge';

export const HeroAnimation = () => {
  return (
    <motion.div 
      className="relative w-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.2 }}
    >
      {/* Main animation container */}
      <div className="relative grid grid-cols-11 gap-2 lg:gap-4 items-stretch min-h-[420px] lg:min-h-[480px]">
        {/* Facebook Marketplace Panel - Left */}
        <div className="col-span-5 lg:col-span-4">
          <FacebookMarketplacePanel />
        </div>

        {/* Data Flow Bridge - Center */}
        <div className="col-span-1 lg:col-span-3">
          <DataFlowBridge />
        </div>

        {/* CRM Workflow Panel - Right */}
        <div className="col-span-5 lg:col-span-4">
          <CRMWorkflowPanel />
        </div>
      </div>

      {/* Bottom glow effect */}
      <div className="absolute -bottom-20 left-1/2 -translate-x-1/2 w-3/4 h-40 bg-accent/10 rounded-full blur-3xl pointer-events-none" />
    </motion.div>
  );
};
