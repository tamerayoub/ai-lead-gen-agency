import { motion } from "framer-motion";
import { MessageSquare, Users, History, Reply, Home, Shield } from "lucide-react";

const features = [
  {
    icon: Users,
    title: "Capture Every Lead",
    description: "Automatically import leads from Facebook Marketplace inquiries into your pipeline. No manual entry required.",
  },
  {
    icon: Home,
    title: "Sync Listings",
    description: "Keep your Facebook Marketplace listings synced with your property inventory in real-time via API.",
  },
  {
    icon: MessageSquare,
    title: "Centralize Conversations",
    description: "Pull all Facebook Marketplace conversations into your workflow. Every message, in one place.",
  },
  {
    icon: History,
    title: "Lead History & Profiles",
    description: "Store complete conversation history and lead profiles. See every interaction at a glance.",
  },
  {
    icon: Reply,
    title: "Reply From Your Workflow",
    description: "Message leads back directly from your property management system. No app switching needed.",
  },
  {
    icon: Shield,
    title: "Enterprise API",
    description: "Robust REST API with webhooks, rate limiting, and enterprise-grade security for your integration.",
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-foreground sm:text-5xl">
            Everything You Need to <span className="text-gradient-brand">Convert Leads</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
            A complete integration platform built for property management teams
          </p>
        </motion.div>

        <div className="mx-auto grid max-w-5xl gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              className="group rounded-2xl border border-border bg-card p-6 shadow-card transition-all duration-300 hover:shadow-card-hover hover:-translate-y-1"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-accent transition-colors group-hover:bg-gradient-brand">
                <feature.icon className="h-6 w-6 text-primary transition-colors group-hover:text-primary-foreground" />
              </div>
              <h3 className="mb-2 text-lg font-bold text-foreground">{feature.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
