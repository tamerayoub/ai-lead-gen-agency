import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => (
  <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-card/80 backdrop-blur-xl">
    <div className="container mx-auto flex h-16 items-center justify-between px-6">
      <div className="flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-brand">
          <span className="text-lg font-bold text-primary-foreground">L2</span>
        </div>
        <span className="text-xl font-bold tracking-tight text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Lead2Lease
        </span>
      </div>
      <div className="hidden items-center gap-8 md:flex">
        <a href="#features" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Features</a>
        <a href="#how-it-works" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">How It Works</a>
        <a href="#pricing" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Pricing</a>
      </div>
      <Button className="bg-gradient-brand shadow-brand hover:opacity-90 transition-opacity">
        Get Started Free <ArrowRight className="ml-2 h-4 w-4" />
      </Button>
    </div>
  </nav>
);

export default Navbar;
