import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import IntegrationFlow from "@/components/IntegrationFlow";
import FeaturesSection from "@/components/FeaturesSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <IntegrationFlow />
      <FeaturesSection />
      <CTASection />
      <Footer />
    </div>
  );
};

export default Index;
