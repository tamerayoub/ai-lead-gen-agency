import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MessageSquare, Users, TrendingUp, ArrowRight, Lock, ChevronRight } from "lucide-react";

const mockConversations = [
  {
    id: 1,
    name: "Sarah Mitchell",
    avatar: "SM",
    listing: "2019 Honda Civic - $15,000",
    lastMessage: "Is this still available? I'm very interested and can meet today!",
    time: "2 min ago",
    unread: 3,
    status: "hot",
  },
  {
    id: 2,
    name: "Michael Chen",
    avatar: "MC",
    listing: "Leather Sofa Set - $800",
    lastMessage: "What's the lowest you can go? I can pay cash.",
    time: "15 min ago",
    unread: 1,
    status: "warm",
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    avatar: "ER",
    listing: "iPhone 14 Pro - $650",
    lastMessage: "Can you deliver to 123 Main St? I can add $20 for delivery.",
    time: "1 hour ago",
    unread: 0,
    status: "new",
  },
];

const mockLeads = [
  { name: "Sarah M.", value: "$15,000", status: "Ready to Buy", score: 95 },
  { name: "Michael C.", value: "$800", status: "Negotiating", score: 72 },
  { name: "Emily R.", value: "$650", status: "New Inquiry", score: 45 },
];

export const LivePreview = () => {
  const [activeTab, setActiveTab] = useState<"messages" | "leads" | "analytics">("messages");

  return (
    <section className="py-20 lg:py-32 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-block px-4 py-1.5 bg-accent/10 text-accent text-sm font-medium rounded-full mb-4">
            Live Preview
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            See What You're Missing
          </h2>
          <p className="text-lg text-muted-foreground">
            This is a preview of what your dashboard could look like. Connect your Facebook account to see your real data.
          </p>
        </div>

        {/* Interactive Dashboard */}
        <div className="max-w-5xl mx-auto">
          <div className="bg-card rounded-2xl shadow-card border border-border overflow-hidden">
            {/* Tab Navigation */}
            <div className="flex border-b border-border">
              {[
                { id: "messages", label: "Messages", icon: MessageSquare, count: 4 },
                { id: "leads", label: "Leads", icon: Users, count: 12 },
                { id: "analytics", label: "Analytics", icon: TrendingUp },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={`flex items-center gap-2 px-6 py-4 text-sm font-medium transition-colors relative ${
                    activeTab === tab.id
                      ? "text-primary"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                  {tab.count && (
                    <span className={`px-2 py-0.5 rounded-full text-xs ${
                      activeTab === tab.id 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-muted text-muted-foreground"
                    }`}>
                      {tab.count}
                    </span>
                  )}
                  {activeTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
                  )}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="p-6">
              {activeTab === "messages" && (
                <div className="space-y-4">
                  {mockConversations.map((conv, i) => (
                    <div
                      key={conv.id}
                      className={`flex items-start gap-4 p-4 rounded-xl transition-all cursor-pointer hover:bg-muted/50 ${
                        conv.unread > 0 ? "bg-primary/5 border border-primary/20" : "bg-muted/30"
                      }`}
                    >
                      <div className="w-12 h-12 rounded-full bg-hero-gradient flex items-center justify-center text-primary-foreground font-semibold">
                        {conv.avatar}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-foreground">{conv.name}</span>
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                              conv.status === "hot" ? "bg-destructive/10 text-destructive" :
                              conv.status === "warm" ? "bg-accent/10 text-accent" :
                              "bg-primary/10 text-primary"
                            }`}>
                              {conv.status === "hot" ? "🔥 Hot Lead" : conv.status === "warm" ? "Warm" : "New"}
                            </span>
                          </div>
                          <span className="text-xs text-muted-foreground">{conv.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{conv.listing}</p>
                        <p className="text-sm text-foreground truncate">{conv.lastMessage}</p>
                      </div>
                      {conv.unread > 0 && (
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-accent flex items-center justify-center text-accent-foreground text-xs font-bold">
                            {conv.unread}
                          </span>
                          <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                  ))}
                  
                  {/* Locked Content */}
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-card z-10" />
                    <div className="opacity-40 blur-sm space-y-4">
                      {[1, 2].map((i) => (
                        <div key={i} className="flex items-start gap-4 p-4 rounded-xl bg-muted/30">
                          <div className="w-12 h-12 rounded-full bg-muted" />
                          <div className="flex-1 space-y-2">
                            <div className="h-4 bg-muted rounded w-32" />
                            <div className="h-3 bg-muted rounded w-48" />
                            <div className="h-3 bg-muted rounded w-full" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "leads" && (
                <div className="space-y-4">
                  <div className="grid gap-4">
                    {mockLeads.map((lead, i) => (
                      <div key={i} className="flex items-center justify-between p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-full bg-hero-gradient flex items-center justify-center text-primary-foreground font-semibold text-sm">
                            {lead.name.split(" ").map(n => n[0]).join("")}
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{lead.name}</p>
                            <p className="text-sm text-muted-foreground">{lead.status}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-foreground">{lead.value}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-primary rounded-full" 
                                style={{ width: `${lead.score}%` }}
                              />
                            </div>
                            <span className="text-xs text-muted-foreground">{lead.score}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Locked */}
                  <div className="relative py-8">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-card z-10" />
                    <div className="opacity-40 blur-sm space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-16 bg-muted rounded-xl" />
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "analytics" && (
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: "Total Leads", value: "127", change: "+12%" },
                      { label: "Response Rate", value: "94%", change: "+5%" },
                      { label: "Avg Response Time", value: "8m", change: "-23%" },
                    ].map((stat, i) => (
                      <div key={i} className="p-4 rounded-xl bg-muted/30 text-center">
                        <p className="text-2xl font-display font-bold text-foreground">{stat.value}</p>
                        <p className="text-sm text-muted-foreground">{stat.label}</p>
                        <p className="text-xs text-primary font-medium mt-1">{stat.change}</p>
                      </div>
                    ))}
                  </div>
                  
                  {/* Chart Placeholder */}
                  <div className="relative h-48 rounded-xl bg-muted/30 overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <Lock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground">Connect to view analytics</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* CTA Footer */}
            <div className="px-6 py-4 bg-muted/50 border-t border-border flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                <Lock className="w-4 h-4 inline-block mr-1" />
                Connect your Facebook to unlock all features
              </p>
              <Button variant="hero" className="group">
                Connect Facebook
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
