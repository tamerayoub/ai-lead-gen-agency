import { MessageSquare } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="py-12 bg-foreground">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-hero-gradient flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-bold text-background">Lead2Lease</span>
          </div>
          
          {/* Links */}
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            {["Privacy Policy", "Terms of Service", "Contact", "Support"].map((link) => (
              <a
                key={link}
                href="#"
                className="text-background/60 hover:text-background transition-colors"
              >
                {link}
              </a>
            ))}
          </div>
          
          {/* Copyright */}
          <p className="text-sm text-background/60">
            © 2024 Lead2Lease. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};
