import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CTAButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
  size?: 'default' | 'lg';
  onClick?: () => void;
}

export const CTAButton = ({ 
  children, 
  variant = 'primary', 
  size = 'default',
  onClick 
}: CTAButtonProps) => {
  return (
    <Button
      onClick={onClick}
      className={`
        group relative overflow-hidden font-semibold transition-all duration-300
        ${size === 'lg' ? 'px-8 py-6 text-lg' : 'px-6 py-3 text-base'}
        ${variant === 'primary' 
          ? 'gradient-primary text-primary-foreground glow-primary hover:scale-105' 
          : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'}
        rounded-full
      `}
    >
      <span className="relative z-10 flex items-center gap-2">
        {children}
        <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
      </span>
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
    </Button>
  );
};
