import { Home } from 'lucide-react';

export const Logo = () => {
  return (
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center glow-primary">
        <Home className="w-5 h-5 text-primary-foreground" />
      </div>
      <span className="text-xl font-bold">
        <span className="text-foreground">lead</span>
        <span className="text-gradient">2</span>
        <span className="text-foreground">lease</span>
      </span>
    </div>
  );
};
