import { useState, useEffect } from 'react';
import { Check, Calendar, MapPin, Home, Sparkles } from 'lucide-react';

interface Message {
  id: number;
  type: 'lead' | 'ai';
  text: string;
  timestamp: string;
  showBooking?: boolean;
}

const chatMessages: Message[] = [
  {
    id: 1,
    type: 'lead',
    text: "Hi! Is the 2BR apartment on Oak Street still available?",
    timestamp: "2:34 PM"
  },
  {
    id: 2,
    type: 'ai',
    text: "Hi there! 👋 Yes, the 2BR at 456 Oak Street is available! It's $1,850/month, 950 sq ft with in-unit laundry. Would you like to schedule a tour?",
    timestamp: "2:34 PM"
  },
  {
    id: 3,
    type: 'lead',
    text: "Yes! Can I see it this Saturday?",
    timestamp: "2:35 PM"
  },
  {
    id: 4,
    type: 'ai',
    text: "Perfect! I have availability on Saturday. What time works best for you - 10am, 1pm, or 3pm?",
    timestamp: "2:35 PM"
  },
  {
    id: 5,
    type: 'lead',
    text: "1pm works great",
    timestamp: "2:36 PM"
  },
  {
    id: 6,
    type: 'ai',
    text: "You're all set! 📅 Tour confirmed for Saturday at 1pm at 456 Oak Street. I'll send you a reminder. What's the best number to reach you?",
    timestamp: "2:36 PM",
    showBooking: true
  }
];

export const AnimatedChatDemo = () => {
  const [visibleMessages, setVisibleMessages] = useState<Message[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    if (currentIndex < chatMessages.length) {
      const nextMessage = chatMessages[currentIndex];
      
      // Show typing indicator for AI messages
      if (nextMessage.type === 'ai') {
        setIsTyping(true);
        const typingTimeout = setTimeout(() => {
          setIsTyping(false);
          setVisibleMessages(prev => [...prev, nextMessage]);
          setCurrentIndex(prev => prev + 1);
        }, 1500);
        return () => clearTimeout(typingTimeout);
      } else {
        // Lead messages appear after a delay
        const messageTimeout = setTimeout(() => {
          setVisibleMessages(prev => [...prev, nextMessage]);
          setCurrentIndex(prev => prev + 1);
        }, 1000);
        return () => clearTimeout(messageTimeout);
      }
    } else {
      // Reset the animation after a pause
      const resetTimeout = setTimeout(() => {
        setVisibleMessages([]);
        setCurrentIndex(0);
      }, 4000);
      return () => clearTimeout(resetTimeout);
    }
  }, [currentIndex]);

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Messenger Header */}
      <div className="bg-card rounded-t-2xl border border-border p-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
          <Home className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-foreground">Oakwood Properties</span>
            <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
          </div>
          <span className="text-xs text-muted-foreground">Usually responds instantly</span>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-facebook/10 border border-facebook/20">
          <svg className="w-4 h-4 text-facebook" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.477 2 2 6.145 2 11.243c0 2.936 1.444 5.544 3.7 7.254V22l3.3-1.8c.88.244 1.819.377 2.8.377h.2c5.523 0 10-4.145 10-9.257S17.523 2 12 2z"/>
          </svg>
          <span className="text-xs font-medium text-facebook">Messenger</span>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="bg-card/50 border-x border-border min-h-[380px] p-4 space-y-4 overflow-hidden">
        {visibleMessages.map((message, index) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'lead' ? 'justify-end' : 'justify-start'} chat-bubble-enter`}
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className={`max-w-[80%] ${message.type === 'lead' ? 'order-1' : 'order-2'}`}>
              <div
                className={`px-4 py-3 rounded-2xl ${
                  message.type === 'lead'
                    ? 'bg-primary text-primary-foreground rounded-br-md'
                    : 'bg-secondary text-secondary-foreground rounded-bl-md'
                }`}
              >
                {message.type === 'ai' && (
                  <div className="flex items-center gap-1 mb-1">
                    <Sparkles className="w-3 h-3 text-primary" />
                    <span className="text-[10px] font-medium text-primary">AI Agent</span>
                  </div>
                )}
                <p className="text-sm leading-relaxed">{message.text}</p>
              </div>
              
              {/* Booking Confirmation Badge */}
              {message.showBooking && (
                <div className="mt-2 p-3 bg-success/10 border border-success/20 rounded-xl chat-bubble-enter">
                  <div className="flex items-center gap-2 text-success">
                    <div className="w-5 h-5 rounded-full bg-success flex items-center justify-center">
                      <Check className="w-3 h-3 text-success-foreground" />
                    </div>
                    <span className="text-xs font-semibold">Tour Booked!</span>
                  </div>
                  <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Saturday, 1pm
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> 456 Oak St
                    </span>
                  </div>
                </div>
              )}
              
              <span className="text-[10px] text-muted-foreground mt-1 block px-1">
                {message.timestamp}
              </span>
            </div>
          </div>
        ))}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex justify-start chat-bubble-enter">
            <div className="bg-secondary px-4 py-3 rounded-2xl rounded-bl-md">
              <div className="flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-primary animate-pulse" />
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-typing" style={{ animationDelay: '0s' }} />
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-typing" style={{ animationDelay: '0.2s' }} />
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-typing" style={{ animationDelay: '0.4s' }} />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="bg-card rounded-b-2xl border border-t-0 border-border p-3 flex items-center gap-3">
        <div className="flex-1 bg-secondary rounded-full px-4 py-2.5 text-sm text-muted-foreground">
          Aa
        </div>
        <button className="w-10 h-10 rounded-full gradient-messenger flex items-center justify-center">
          <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
          </svg>
        </button>
      </div>
    </div>
  );
};
