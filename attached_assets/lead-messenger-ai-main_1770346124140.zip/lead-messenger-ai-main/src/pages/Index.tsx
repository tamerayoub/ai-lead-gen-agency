import { Gauge, CalendarClock, Rocket, Send, Target } from 'lucide-react';
import { AnimatedChatDemo } from '@/components/AnimatedChatDemo';
import { FacebookBadge } from '@/components/FacebookBadge';
import { CTAButton } from '@/components/CTAButton';
import { StatCard } from '@/components/StatCard';
import { Logo } from '@/components/Logo';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Logo />
          <CTAButton variant="primary" size="default">
            Get Started Free
          </CTAButton>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              {/* Facebook Integration Badge */}
              <div className="inline-block">
                <FacebookBadge />
              </div>

              {/* Headline */}
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight">
                  Your AI Leasing Agent
                  <span className="block text-gradient">Never Sleeps</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-lg">
                  Automatically respond to Facebook Marketplace leads, answer questions, 
                  and book property tours — 24/7, without lifting a finger.
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4">
                <StatCard 
                  value="< 30s" 
                  label="Response Time" 
                  icon={<Gauge className="w-6 h-6" />} 
                />
                <StatCard 
                  value="3x" 
                  label="More Tours Booked" 
                  icon={<Rocket className="w-6 h-6" />} 
                />
              </div>

              {/* CTA */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <CTAButton variant="primary" size="lg">
                  Start Automating Now
                </CTAButton>
              </div>

              {/* Social Proof */}
              <div className="flex items-center gap-4 pt-2">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div 
                      key={i} 
                      className="w-8 h-8 rounded-full border-2 border-background bg-secondary flex items-center justify-center text-xs font-medium text-muted-foreground"
                    >
                      {['JM', 'SK', 'AR', 'LP'][i - 1]}
                    </div>
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  Trusted by <span className="font-semibold text-foreground">500+</span> property managers
                </span>
              </div>
            </div>

            {/* Right - Chat Demo */}
            <div className="relative">
              {/* Glow Effect */}
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 via-messenger/10 to-accent/20 blur-3xl opacity-50 rounded-3xl" />
              
              {/* Chat Demo */}
              <div className="relative animate-float">
                <AnimatedChatDemo />
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-primary/10 rounded-full blur-2xl" />
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-accent/10 rounded-full blur-2xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 border-t border-border">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why Property Managers Love <span className="text-gradient">lead2lease</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Turn Facebook Marketplace into your #1 leasing channel
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Send className="w-8 h-8" />}
              title="Instant Responses"
              description="Never miss a lead. Our AI responds to inquiries in under 30 seconds, 24/7."
            />
            <FeatureCard
              icon={<CalendarClock className="w-8 h-8" />}
              title="Automated Scheduling"
              description="AI books tours directly into your calendar. No back-and-forth needed."
            />
            <FeatureCard
              icon={<Target className="w-8 h-8" />}
              title="Higher Conversion"
              description="Convert 3x more leads into tours with instant, intelligent follow-up."
            />
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-6 bg-card/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Set Up in <span className="text-gradient">5 Minutes</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <StepCard
              number="1"
              title="Connect Facebook"
              description="Link your Facebook Marketplace listings in one click"
            />
            <StepCard
              number="2"
              title="Set Your Preferences"
              description="Tell us your properties, pricing, and tour availability"
            />
            <StepCard
              number="3"
              title="Let AI Work"
              description="Watch tours get booked while you focus on closings"
            />
          </div>

          {/* Final CTA */}
          <div className="text-center mt-16">
            <CTAButton variant="primary" size="lg">
              Start Your Free Trial
            </CTAButton>
            <p className="mt-4 text-sm text-muted-foreground">
              No credit card required · Cancel anytime
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-border">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <Logo />
          <div className="flex items-center gap-6">
            <FacebookBadge />
          </div>
          <p className="text-sm text-muted-foreground">
            © 2024 lead2lease. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

const FeatureCard = ({ 
  icon, 
  title, 
  description 
}: { 
  icon: React.ReactNode; 
  title: string; 
  description: string 
}) => (
  <div className="p-8 bg-card border border-border rounded-2xl hover:border-primary/30 transition-all hover:glow-primary group">
    <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-3">{title}</h3>
    <p className="text-muted-foreground">{description}</p>
  </div>
);

const StepCard = ({ 
  number, 
  title, 
  description 
}: { 
  number: string; 
  title: string; 
  description: string 
}) => (
  <div className="text-center">
    <div className="w-16 h-16 rounded-full gradient-primary text-primary-foreground text-2xl font-bold flex items-center justify-center mx-auto mb-6 glow-primary">
      {number}
    </div>
    <h3 className="text-xl font-bold mb-2">{title}</h3>
    <p className="text-muted-foreground">{description}</p>
  </div>
);

export default Index;
