import { ArrowRight, CheckCircle } from "lucide-react";

const benefits = [
  "Free setup — no upfront cost",
  "AI trained on your business",
  "Live in under 48 hours",
  "Full money-back guarantee",
];

const CTASection = () => (
  <section className="py-24 px-4">
    <div className="max-w-3xl mx-auto text-center">
      <div className="bg-hero-gradient rounded-3xl p-10 md:p-16 relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary-foreground/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-primary-foreground/5 rounded-full translate-y-1/2 -translate-x-1/2" />

        <div className="relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold font-display text-primary-foreground mb-4">
            Ready to Turn Visitors Into Leads?
          </h2>
          <p className="text-primary-foreground/80 text-lg mb-8 max-w-lg mx-auto">
            Get your AI-powered lead generation assistant set up on your website — completely free.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {benefits.map((b, i) => (
              <div key={i} className="flex items-center gap-2 text-primary-foreground/90 text-sm">
                <CheckCircle className="w-4 h-4 text-green-300" />
                <span>{b}</span>
              </div>
            ))}
          </div>

          <button className="inline-flex items-center gap-2 bg-primary-foreground text-primary px-8 py-4 rounded-xl font-semibold text-lg hover:opacity-90 transition-opacity shadow-soft group">
            Get Started Free
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>

          <p className="text-xs text-primary-foreground/60 mt-4">No credit card required • Cancel anytime</p>
        </div>
      </div>
    </div>
  </section>
);

export default CTASection;
