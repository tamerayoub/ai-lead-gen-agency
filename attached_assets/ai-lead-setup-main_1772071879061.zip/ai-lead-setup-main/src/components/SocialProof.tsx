import { Star } from "lucide-react";

const stats = [
  { value: "2,400+", label: "Leads Generated" },
  { value: "150+", label: "Businesses Served" },
  { value: "97%", label: "Client Retention" },
  { value: "4.9/5", label: "Average Rating" },
];

const testimonials = [
  {
    name: "Sarah Mitchell",
    role: "CEO, BrightSmile Dental",
    text: "Within the first month, we captured 87 new patient leads. The AI assistant works 24/7 and never misses a potential client.",
    stars: 5,
  },
  {
    name: "James Rodriguez",
    role: "Owner, Elite Fitness Gym",
    text: "Setup was completely hands-off. They installed everything and we started seeing results the same week. Incredible ROI.",
    stars: 5,
  },
  {
    name: "Emily Chen",
    role: "Director, Prestige Real Estate",
    text: "The money-back guarantee gave us confidence to try it. Turns out we didn't need it — leads increased by 340% in 60 days.",
    stars: 5,
  },
];

const SocialProof = () => (
  <section className="py-24 px-4 bg-muted/50">
    <div className="max-w-6xl mx-auto">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
        {stats.map((s, i) => (
          <div key={i} className="text-center" style={{ animation: `count-up 0.6s ease-out ${i * 0.1}s both` }}>
            <p className="text-3xl md:text-4xl font-bold font-display text-gradient">{s.value}</p>
            <p className="text-sm text-muted-foreground mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Testimonials */}
      <div className="text-center mb-12">
        <p className="text-sm font-semibold tracking-widest uppercase text-primary mb-3">Trusted By Businesses</p>
        <h2 className="text-3xl md:text-4xl font-bold font-display text-foreground">
          Real Results From Real Clients
        </h2>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        {testimonials.map((t, i) => (
          <div
            key={i}
            className="glass-card rounded-2xl p-6 hover:shadow-glow transition-all duration-300"
          >
            <div className="flex gap-0.5 mb-4">
              {Array.from({ length: t.stars }).map((_, j) => (
                <Star key={j} className="w-4 h-4 fill-primary text-primary" />
              ))}
            </div>
            <p className="text-sm text-foreground leading-relaxed mb-5">"{t.text}"</p>
            <div>
              <p className="text-sm font-semibold text-foreground">{t.name}</p>
              <p className="text-xs text-muted-foreground">{t.role}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Logos */}
      <div className="mt-16 text-center">
        <p className="text-xs uppercase tracking-widest text-muted-foreground mb-6">Trusted by industry leaders</p>
        <div className="flex flex-wrap justify-center gap-8 opacity-40">
          {["TechCorp", "MediGroup", "FitChain", "RealtyPro", "EduLearn"].map((name) => (
            <span key={name} className="text-lg font-bold font-display text-foreground">{name}</span>
          ))}
        </div>
      </div>
    </div>
  </section>
);

export default SocialProof;
