import { Settings, Zap, ShieldCheck, DollarSign } from "lucide-react";

const props = [
  {
    icon: Settings,
    title: "Setup For You",
    description: "We handle the entire installation, configuration, and integration — zero technical skills required on your end.",
  },
  {
    icon: Zap,
    title: "Try Setup For You",
    description: "Not sure yet? Let us set it up and show you the results first. Experience the power before you commit.",
  },
  {
    icon: DollarSign,
    title: "Setup For You For Free",
    description: "We'll install the AI assistant on your website at no cost. You only pay when you see real leads coming in.",
  },
  {
    icon: ShieldCheck,
    title: "No Results? Get Your Money Back",
    description: "We stand behind our system. If you don't see measurable results, we'll give you a full refund. No questions asked.",
  },
];

const ValueProps = () => (
  <section className="py-24 px-4">
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-16">
        <p className="text-sm font-semibold tracking-widest uppercase text-primary mb-3">Why Choose Us</p>
        <h2 className="text-3xl md:text-4xl font-bold font-display text-foreground">
          Zero Risk. Maximum Results.
        </h2>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {props.map((p, i) => (
          <div
            key={i}
            className="glass-card rounded-2xl p-6 text-center group hover:shadow-glow transition-all duration-300 hover:-translate-y-1"
          >
            <div className="w-14 h-14 rounded-2xl bg-hero-gradient flex items-center justify-center mx-auto mb-5 group-hover:scale-110 transition-transform duration-300">
              <p.icon className="w-6 h-6 text-primary-foreground" />
            </div>
            <h3 className="text-lg font-bold font-display text-foreground mb-2">{p.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{p.description}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default ValueProps;
