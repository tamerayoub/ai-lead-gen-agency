import { useEffect, useState } from "react";
import { MessageSquare, Send } from "lucide-react";

const chatMessages = [
  { role: "visitor" as const, text: "Hi, I'm interested in your services. What do you offer?" },
  { role: "ai" as const, text: "Welcome! We offer web design, SEO, and digital marketing. What's your business about?" },
  { role: "visitor" as const, text: "I run a dental clinic. Need more patients." },
  { role: "ai" as const, text: "Great! I can help grow your patient base. Can I get your name and email to set up a free consultation?" },
  { role: "visitor" as const, text: "Sure! It's Dr. Smith, drsmith@email.com" },
  { role: "ai" as const, text: "Perfect, Dr. Smith! 🎉 Our team will reach out within 24 hours. You're going to love the results!" },
];

const TypingIndicator = () => (
  <div className="flex items-center gap-1 px-4 py-3">
    {[0, 1, 2].map((i) => (
      <span
        key={i}
        className="w-2 h-2 rounded-full bg-primary/50"
        style={{
          animation: `typing-dot 1.4s ease-in-out ${i * 0.2}s infinite`,
        }}
      />
    ))}
  </div>
);

const ChatDemo = () => {
  const [visibleMessages, setVisibleMessages] = useState<number>(0);
  const [isTyping, setIsTyping] = useState(false);
  const [leadCaptured, setLeadCaptured] = useState(false);

  useEffect(() => {
    if (visibleMessages >= chatMessages.length) {
      setTimeout(() => setLeadCaptured(true), 800);
      return;
    }

    const nextMsg = chatMessages[visibleMessages];
    const delay = visibleMessages === 0 ? 1200 : nextMsg.role === "ai" ? 2000 : 1500;

    const typingTimer = setTimeout(() => {
      if (nextMsg.role === "ai") {
        setIsTyping(true);
        setTimeout(() => {
          setIsTyping(false);
          setVisibleMessages((v) => v + 1);
        }, 1200);
      } else {
        setVisibleMessages((v) => v + 1);
      }
    }, delay);

    return () => clearTimeout(typingTimer);
  }, [visibleMessages]);

  useEffect(() => {
    const resetTimer = setTimeout(() => {
      if (leadCaptured) {
        setVisibleMessages(0);
        setLeadCaptured(false);
      }
    }, 5000);
    return () => clearTimeout(resetTimer);
  }, [leadCaptured]);

  return (
    <div className="relative w-full max-w-md mx-auto">
      {/* Browser frame */}
      <div className="rounded-xl overflow-hidden shadow-glow border border-border bg-card">
        {/* Browser bar */}
        <div className="flex items-center gap-2 px-4 py-3 bg-muted border-b border-border">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-destructive/60" />
            <span className="w-3 h-3 rounded-full bg-yellow-400/60" />
            <span className="w-3 h-3 rounded-full bg-green-400/60" />
          </div>
          <div className="flex-1 ml-2">
            <div className="bg-background rounded-md px-3 py-1 text-xs text-muted-foreground font-mono">
              yourbusiness.com
            </div>
          </div>
        </div>

        {/* Website content - taller to simulate a real page */}
        <div className="relative p-4 bg-background min-h-[380px]">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-5 w-24 rounded bg-muted" />
            <div className="ml-auto flex gap-2">
              <div className="h-3 w-12 rounded bg-muted" />
              <div className="h-3 w-12 rounded bg-muted" />
              <div className="h-3 w-12 rounded bg-muted" />
            </div>
          </div>
          <div className="space-y-2 mb-4">
            <div className="h-8 w-3/4 rounded bg-muted" />
            <div className="h-3 w-full rounded bg-muted/60" />
            <div className="h-3 w-5/6 rounded bg-muted/60" />
          </div>
          <div className="flex gap-2 mb-6">
            <div className="h-8 w-20 rounded bg-primary/20" />
            <div className="h-8 w-20 rounded bg-muted" />
          </div>
          <div className="space-y-2">
            <div className="h-3 w-full rounded bg-muted/40" />
            <div className="h-3 w-4/5 rounded bg-muted/40" />
            <div className="h-3 w-full rounded bg-muted/40" />
            <div className="h-3 w-3/4 rounded bg-muted/40" />
          </div>

          {/* Chat widget - bottom left overlay */}
          <div className="absolute bottom-3 right-3 w-[260px] rounded-xl overflow-hidden shadow-glow border border-border bg-card">
            {/* Chat header */}
            <div className="bg-hero-gradient px-3 py-2 flex items-center gap-2">
              <div className="relative">
                <MessageSquare className="w-4 h-4 text-primary-foreground" />
                <span
                  className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full"
                  style={{
                    boxShadow: "0 0 0 2px hsl(var(--primary))",
                  }}
                />
              </div>
              <span className="text-xs font-semibold text-primary-foreground">AI Assistant</span>
              <span className="text-[10px] text-primary-foreground/70 ml-auto">Online</span>
            </div>

            {/* Chat messages */}
            <div className="p-2 space-y-1.5 bg-background min-h-[200px] max-h-[200px] overflow-hidden">
              {chatMessages.slice(0, visibleMessages).map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "visitor" ? "justify-end" : "justify-start"}`}
                  style={{
                    animation: "chat-appear 0.4s ease-out forwards",
                  }}
                >
                  <div
                    className={`max-w-[85%] px-2.5 py-1.5 rounded-xl text-[11px] leading-relaxed ${
                      msg.role === "visitor"
                        ? "bg-hero-gradient text-primary-foreground rounded-br-sm"
                        : "bg-muted text-foreground rounded-bl-sm"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-xl rounded-bl-sm">
                    <TypingIndicator />
                  </div>
                </div>
              )}
            </div>

            {/* Input bar */}
            <div className="flex items-center gap-1.5 px-2 py-1.5 border-t border-border bg-background">
              <div className="flex-1 bg-muted rounded-md px-2 py-1.5 text-[10px] text-muted-foreground">
                Type a message...
              </div>
              <button className="p-1.5 rounded-md bg-hero-gradient text-primary-foreground">
                <Send className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Lead captured notification */}
      {leadCaptured && (
        <div
          className="absolute -bottom-4 left-1/2 -translate-x-1/2 glass-card rounded-xl px-5 py-3 flex items-center gap-3"
          style={{ animation: "chat-appear 0.5s ease-out forwards" }}
        >
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
              <span className="text-lg">✅</span>
            </div>
            <span
              className="absolute inset-0 rounded-full bg-green-400/30"
              style={{ animation: "pulse-ring 1.5s ease-out infinite" }}
            />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">New Lead Captured!</p>
            <p className="text-xs text-muted-foreground">Dr. Smith — drsmith@email.com</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatDemo;
