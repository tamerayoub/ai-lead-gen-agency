import { Bot } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border py-10 px-4">
    <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <div className="w-7 h-7 rounded-md bg-hero-gradient flex items-center justify-center">
          <Bot className="w-4 h-4 text-primary-foreground" />
        </div>
        <span className="font-display font-bold text-foreground">LeadGenAI</span>
      </div>
      <p className="text-xs text-muted-foreground">© 2026 LeadGenAI. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;
