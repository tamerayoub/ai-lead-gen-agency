import { Bot } from "lucide-react";

const Navbar = () => (
  <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-border/50">
    <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-hero-gradient flex items-center justify-center">
          <Bot className="w-5 h-5 text-primary-foreground" />
        </div>
        <span className="font-display font-bold text-lg text-foreground">LeadGenAI</span>
      </div>
      <button className="bg-hero-gradient text-primary-foreground px-5 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity">
        Get Started
      </button>
    </div>
  </nav>
);

export default Navbar;
