import { ArrowRight } from "lucide-react";
import ChatDemo from "./ChatDemo";

const HeroSection = () => (
  <section className="pt-28 pb-20 px-4 overflow-hidden">
    <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
      {/* Left copy */}
      <div>
        <div className="inline-flex items-center gap-2 bg-accent rounded-full px-4 py-1.5 mb-6">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-xs font-medium text-accent-foreground">AI-Powered Lead Generation</span>
        </div>
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-display leading-tight text-foreground mb-6">
          Turn Every Visitor Into a{" "}
          <span className="text-gradient">Qualified Lead</span>
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-lg">
          Our AI assistant engages your website visitors 24/7, answers their questions, and captures their details — so you never miss a potential customer again.
        </p>
        <div className="flex flex-wrap gap-4">
          <button className="inline-flex items-center gap-2 bg-hero-gradient text-primary-foreground px-7 py-3.5 rounded-xl font-semibold hover:opacity-90 transition-opacity shadow-glow group">
            Get Setup For Free
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
          <button className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl font-semibold border border-border text-foreground hover:bg-muted transition-colors">
            Watch Demo
          </button>
        </div>
        <p className="text-xs text-muted-foreground mt-4">✓ Free setup &nbsp; ✓ No credit card &nbsp; ✓ Money-back guarantee</p>
      </div>

      {/* Right demo */}
      <div className="animate-float">
        <ChatDemo />
      </div>
    </div>
  </section>
);

export default HeroSection;
