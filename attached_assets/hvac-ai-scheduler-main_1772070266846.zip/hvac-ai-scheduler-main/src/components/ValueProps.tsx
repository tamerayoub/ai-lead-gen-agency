import { motion } from "framer-motion";
import { Shield, Zap, Gift, RotateCcw } from "lucide-react";

const props = [
  {
    icon: Zap,
    title: "Setup For You",
    description: "We handle everything. From integration to going live—zero work on your end.",
  },
  {
    icon: Gift,
    title: "Setup For You For Free",
    description: "No upfront costs. We build and launch your AI system at zero cost to start.",
  },
  {
    icon: Shield,
    title: "Try Setup For You",
    description: "See it in action first. Low-risk trial so you experience the results before committing.",
  },
  {
    icon: RotateCcw,
    title: "No Results? Money Back.",
    description: "If we don't deliver booked appointments, you pay nothing. Simple as that.",
  },
];

export default function ValueProps() {
  return (
    <section className="py-16 md:py-24 bg-card">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-3">
            Zero Risk. <span className="text-gradient">Maximum Results.</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            We've removed every barrier so you can focus on what you do best—running your business.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {props.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group p-6 rounded-2xl border border-border bg-background hover:shadow-glow transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <item.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold font-display mb-2 text-foreground">{item.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
