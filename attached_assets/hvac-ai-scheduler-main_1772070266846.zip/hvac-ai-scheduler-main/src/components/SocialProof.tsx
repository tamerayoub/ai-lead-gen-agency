import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "James Patterson",
    role: "Owner, Patterson Services",
    text: "We went from missing 40% of calls to booking every single one. Revenue jumped 35% in the first month alone.",
    stars: 5,
  },
  {
    name: "Maria Gonzalez",
    role: "Manager, Bright Solutions Co.",
    text: "The AI books appointments better than my front desk ever did. Our team can finally focus on the actual work instead of playing phone tag.",
    stars: 5,
  },
  {
    name: "David Chen",
    role: "Owner, Chen & Associates",
    text: "Setup was literally done for me. I didn't touch a thing. Within 48 hours, the AI was answering calls and filling my calendar.",
    stars: 5,
  },
];

const stats = [
  { value: "500+", label: "Businesses Served" },
  { value: "2.4M", label: "Appointments Booked" },
  { value: "35%", label: "Avg. Revenue Increase" },
  { value: "<3s", label: "Response Time" },
];

export default function SocialProof() {
  return (
    <section className="py-16 md:py-24 bg-card">
      <div className="container mx-auto px-4">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16 max-w-4xl mx-auto">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center"
            >
              <p className="text-3xl md:text-4xl font-extrabold font-display text-gradient">{stat.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-3">
            Trusted by Business Owners <span className="text-gradient">Nationwide</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-6 rounded-2xl bg-background border border-border hover:shadow-glow transition-shadow"
            >
              <Quote className="w-8 h-8 text-primary/20 mb-3" />
              <p className="text-sm text-foreground leading-relaxed mb-4">"{t.text}"</p>
              <div className="flex items-center gap-1 mb-3">
                {Array.from({ length: t.stars }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-warning text-warning" />
                ))}
              </div>
              <p className="text-sm font-semibold text-foreground">{t.name}</p>
              <p className="text-xs text-muted-foreground">{t.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
