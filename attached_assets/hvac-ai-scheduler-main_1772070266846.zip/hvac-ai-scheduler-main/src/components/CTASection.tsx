import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CTASection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative max-w-4xl mx-auto rounded-3xl bg-hero-gradient p-10 md:p-16 text-center overflow-hidden"
        >
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,hsl(210_100%_60%/0.3),transparent_60%)]" />

          <div className="relative">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-extrabold font-display text-primary-foreground mb-4">
              Ready to Never Miss a Lead Again?
            </h2>
            <p className="text-primary-foreground/80 text-lg max-w-2xl mx-auto mb-8">
              We'll set everything up for you—for free. If it doesn't deliver results, you don't pay a dime.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
              <Button
                size="lg"
                variant="secondary"
                className="text-base px-8 py-6 font-semibold shadow-lg hover:shadow-xl transition-shadow"
              >
                Get Started Free
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            <div className="flex items-center justify-center gap-2 text-primary-foreground/70 text-sm">
              <ShieldCheck className="w-4 h-4" />
              <span>No credit card required • Setup in 48 hours • Cancel anytime</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
