import { Zap } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-10 border-t border-border bg-card">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-hero-gradient flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-bold font-display text-foreground">LeadFlow AI</span>
          </div>
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} LeadFlow AI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
