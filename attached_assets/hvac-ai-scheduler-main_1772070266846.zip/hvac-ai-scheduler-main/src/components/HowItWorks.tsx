import { motion } from "framer-motion";
import { PhoneIncoming, BrainCircuit, CalendarCheck } from "lucide-react";

const steps = [
  {
    icon: PhoneIncoming,
    step: "01",
    title: "Customer Calls In",
    description: "A potential customer calls your business needing service. Our AI picks up instantly—day or night.",
  },
  {
    icon: BrainCircuit,
    step: "02",
    title: "AI Qualifies & Schedules",
    description: "The AI understands their issue, checks your real-time availability, and books the perfect slot.",
  },
  {
    icon: CalendarCheck,
    step: "03",
    title: "You Show Up & Get Paid",
    description: "You get a notification with all the details. The customer gets a confirmation. Everyone wins.",
  },
];

export default function HowItWorks() {
  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-3">
            How It <span className="text-gradient">Works</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Three simple steps to a fully booked schedule.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((item, i) => (
            <motion.div
              key={item.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative text-center"
            >
              {i < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-px border-t-2 border-dashed border-border" />
              )}
              <div className="w-20 h-20 mx-auto rounded-2xl bg-hero-gradient-subtle flex items-center justify-center mb-5 relative">
                <item.icon className="w-8 h-8 text-primary" />
                <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                  {item.step}
                </span>
              </div>
              <h3 className="text-xl font-bold font-display mb-2 text-foreground">{item.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
