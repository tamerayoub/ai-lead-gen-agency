import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ValueProps from "@/components/ValueProps";
import HowItWorks from "@/components/HowItWorks";
import SocialProof from "@/components/SocialProof";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <ValueProps />
      <div id="how">
        <HowItWorks />
      </div>
      <div id="results">
        <SocialProof />
      </div>
      <div id="cta">
        <CTASection />
      </div>
      <Footer />
    </div>
  );
};

export default Index;
