import { Phone, Zap, Shield, TrendingUp, CheckCircle2, Star, ArrowRight, Users, BarChart3 } from "lucide-react";
import VoiceAgentDemo from "@/components/VoiceAgentDemo";

const guarantees = [
  { icon: Zap, text: "Setup For You" },
  { icon: Phone, text: "Try Setup For You" },
  { icon: Shield, text: "Setup For You For Free" },
  { icon: TrendingUp, text: "No Results? Get Your Money Back" },
];

const stats = [
  { value: "2,400+", label: "Leads Generated" },
  { value: "340%", label: "Avg ROI Increase" },
  { value: "98%", label: "Client Satisfaction" },
  { value: "50+", label: "Businesses Served" },
];

const testimonials = [
  {
    name: "James Carter",
    role: "CEO, TechFlow",
    text: "We saw a 400% increase in qualified leads within the first month. The AI voice agent handles calls so naturally our prospects can't tell the difference.",
    rating: 5,
  },
  {
    name: "Sarah Mitchell",
    role: "Founder, GrowthLab",
    text: "Setup was done completely for us — we didn't lift a finger. Now our pipeline is overflowing with high-quality leads on autopilot.",
    rating: 5,
  },
  {
    name: "David Park",
    role: "VP Sales, ScaleUp",
    text: "The money-back guarantee gave us confidence to try it. Three months in and we've 5x'd our outbound conversions.",
    rating: 5,
  },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-lg text-foreground">LeadGen AI</span>
          </div>
          <a
            href="#cta"
            className="bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            Get Started
          </a>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-28 pb-16 lg:pt-36 lg:pb-24">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-full px-4 py-1.5">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="text-xs font-medium text-primary">AI-Powered Lead Generation</span>
              </div>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-[1.1] tracking-tight">
                Turn Every Call Into a{" "}
                <span className="text-gradient">Qualified Lead</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
                Our AI voice agents call, qualify, and book meetings with your ideal
                prospects — completely done for you with zero effort on your end.
              </p>

              {/* Guarantees */}
              <div className="grid grid-cols-2 gap-3">
                {guarantees.map((g) => (
                  <div key={g.text} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                    <span className="text-sm font-medium text-foreground">{g.text}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="#cta"
                  className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-xl text-base font-semibold hover:opacity-90 transition-opacity shadow-glow"
                >
                  Get Started Free
                  <ArrowRight className="w-4 h-4" />
                </a>
                <a
                  href="#demo"
                  className="inline-flex items-center justify-center gap-2 bg-card text-foreground border border-border px-8 py-4 rounded-xl text-base font-semibold hover:bg-muted transition-colors"
                >
                  Watch Demo
                </a>
              </div>
            </div>

            {/* Voice Agent Demo */}
            <div className="animate-float" id="demo">
              <VoiceAgentDemo />
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-y border-border bg-muted/50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <p className="font-display text-3xl lg:text-4xl font-bold text-gradient">{s.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 lg:py-28">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground text-lg">
              Three simple steps to flood your pipeline with qualified leads.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                icon: Users,
                title: "We Set It Up For You",
                desc: "Share your ideal customer profile. Our team builds your custom AI voice agent, scripts, and targeting — at no cost.",
              },
              {
                step: "02",
                icon: Phone,
                title: "AI Calls & Qualifies",
                desc: "Your AI agent makes natural-sounding calls 24/7, qualifying leads and booking meetings directly on your calendar.",
              },
              {
                step: "03",
                icon: BarChart3,
                title: "You Close Deals",
                desc: "Show up to pre-qualified meetings ready to close. Track everything in your real-time dashboard.",
              },
            ].map((item) => (
              <div
                key={item.step}
                className="relative bg-card border border-border rounded-2xl p-8 shadow-card hover:shadow-soft transition-shadow group"
              >
                <span className="text-6xl font-display font-bold text-primary/5 absolute top-4 right-6">
                  {item.step}
                </span>
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                  <item.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-display text-xl font-bold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20 lg:py-28 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Trusted by Growing Businesses
            </h2>
            <p className="text-muted-foreground text-lg">
              Join 50+ companies already scaling their outbound with AI.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t) => (
              <div key={t.name} className="bg-card border border-border rounded-2xl p-8 shadow-card">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground text-sm leading-relaxed mb-6">"{t.text}"</p>
                <div>
                  <p className="font-semibold text-foreground text-sm">{t.name}</p>
                  <p className="text-muted-foreground text-xs">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="cta" className="py-20 lg:py-28">
        <div className="container mx-auto px-6">
          <div className="bg-hero-gradient rounded-3xl p-12 lg:p-20 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,hsl(217_91%_60%/0.3),transparent_60%)]" />
            <div className="relative z-10">
              <h2 className="font-display text-3xl lg:text-5xl font-bold text-primary-foreground mb-4 leading-tight">
                Ready to 10x Your Leads?
              </h2>
              <p className="text-primary-foreground/70 text-lg mb-8 max-w-lg mx-auto">
                Get your AI voice agent set up for free. No technical skills needed —
                we handle everything. No results? Full money back.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="#"
                  className="inline-flex items-center justify-center gap-2 bg-primary-foreground text-foreground px-8 py-4 rounded-xl text-base font-semibold hover:opacity-90 transition-opacity"
                >
                  Start For Free
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-6 mt-8">
                {["Setup For You", "100% Free Trial", "Money-Back Guarantee"].map((item) => (
                  <div key={item} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary-foreground/70" />
                    <span className="text-sm text-primary-foreground/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t border-border">
        <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
              <Zap className="w-3 h-3 text-primary-foreground" />
            </div>
            <span className="font-display font-semibold text-sm text-foreground">LeadGen AI</span>
          </div>
          <p className="text-xs text-muted-foreground">
            © 2026 LeadGen AI. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
