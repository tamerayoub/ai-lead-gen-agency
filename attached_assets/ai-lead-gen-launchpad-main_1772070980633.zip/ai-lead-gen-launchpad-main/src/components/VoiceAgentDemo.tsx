import { useEffect, useState } from "react";

const VoiceAgentDemo = () => {
  const [stage, setStage] = useState(0);
  const [typing, setTyping] = useState("");

  const conversation = [
    { role: "agent", text: "Hi! This is Sarah from LeadGen AI. Am I speaking with Michael?" },
    { role: "lead", text: "Yes, this is Michael. What's this about?" },
    { role: "agent", text: "We noticed your company might benefit from automated lead generation. Do you have 2 minutes?" },
    { role: "lead", text: "Sure, I'm interested. Tell me more." },
    { role: "agent", text: "Great! I'll schedule a demo for you. What time works best this week?" },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setStage((prev) => (prev + 1) % conversation.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const msg = conversation[stage].text;
    setTyping("");
    let i = 0;
    const typeInterval = setInterval(() => {
      setTyping(msg.slice(0, i + 1));
      i++;
      if (i >= msg.length) clearInterval(typeInterval);
    }, 25);
    return () => clearInterval(typeInterval);
  }, [stage]);

  return (
    <div className="relative w-full max-w-lg mx-auto">
      {/* Browser mockup */}
      <div className="rounded-xl overflow-hidden shadow-card border border-border bg-card">
        {/* Browser bar */}
        <div className="flex items-center gap-2 px-4 py-3 bg-muted border-b border-border">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-destructive/60" />
            <div className="w-3 h-3 rounded-full bg-accent/60" />
            <div className="w-3 h-3 rounded-full bg-primary/40" />
          </div>
          <div className="flex-1 mx-4">
            <div className="bg-card rounded-md px-3 py-1 text-xs text-muted-foreground text-center">
              yourcompany.com
            </div>
          </div>
        </div>

        {/* Website content */}
        <div className="p-6 space-y-4 min-h-[340px] bg-card relative">
          {/* Fake website header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="text-primary font-bold text-sm font-display">YC</span>
              </div>
              <span className="text-sm font-medium text-foreground">YourCompany</span>
            </div>
            <div className="flex gap-4 text-xs text-muted-foreground">
              <span>Products</span>
              <span>About</span>
              <span>Contact</span>
            </div>
          </div>

          {/* AI Voice Widget - overlaid */}
          <div className="absolute bottom-4 right-4 z-10">
            <div className="relative">
              {/* Pulse rings */}
              <div className="absolute inset-0 rounded-full bg-primary/20 animate-pulse-ring" />
              <div className="absolute -inset-2 rounded-full bg-primary/10 animate-pulse-ring" style={{ animationDelay: "0.5s" }} />
              <button className="relative w-14 h-14 rounded-full bg-primary flex items-center justify-center shadow-glow">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-primary-foreground">
                  <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3Z" fill="currentColor" />
                  <path d="M19 10v2a7 7 0 0 1-14 0v-2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <line x1="12" y1="19" x2="12" y2="23" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </button>
            </div>
          </div>

          {/* Voice Call UI */}
          <div className="bg-muted rounded-xl p-4 border border-border">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-primary">
                  <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3Z" fill="currentColor" />
                  <path d="M19 10v2a7 7 0 0 1-14 0v-2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">AI Voice Agent</p>
                <p className="text-xs text-primary font-medium">● Live Call</p>
              </div>
              <div className="ml-auto flex items-center gap-1">
                {[0, 1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="w-1 bg-primary rounded-full animate-voice-wave"
                    style={{
                      animationDelay: `${i * 0.15}s`,
                      minHeight: "8px",
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Conversation */}
            <div className="space-y-3">
              {conversation.slice(0, stage + 1).map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "lead" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] px-3 py-2 rounded-xl text-xs ${
                      msg.role === "agent"
                        ? "bg-primary text-primary-foreground rounded-bl-sm"
                        : "bg-card text-foreground border border-border rounded-br-sm"
                    }`}
                  >
                    {i === stage ? typing : msg.text}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Fake lead captured badge */}
          {stage >= 3 && (
            <div className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-lg px-3 py-2 animate-fade-in">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="text-primary">
                <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="text-xs font-medium text-primary">Lead Qualified — Demo Scheduled ✓</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VoiceAgentDemo;
